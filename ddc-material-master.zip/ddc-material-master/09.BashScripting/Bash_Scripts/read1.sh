#!/bin/bash

echo "Enter your skills:"
read SKILLS

echo "Your $SKILLS skills are very popular in IT Industry"

read -p 'Username: ' USR
read -sp 'Password: ' pass

echo

echo "Login Successfull: Welcome USER $USR,"
