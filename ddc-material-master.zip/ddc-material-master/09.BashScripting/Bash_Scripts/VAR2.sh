#!/bin/bash

VAR1=foo
echo $VAR1
echo $NAME
